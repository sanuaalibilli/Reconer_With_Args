#TO RUN THE PROGRAM USE BELOW COMMAND LINE:
>python Reconer_Main.py -M Mappings.txt -A Aliases.txt -F D:\tempDir\Input_Files\mhub_mdw_recon_orig_loan_{YYYYMMDD}.dat -B 20200610 -D Sample_Input_File -C config.properties -L INFO

#('-M','--Mappings',help="Mappings File Path", required = True)
#('-A','--Aliases',help="Aliases File Path",required = True)
#('-C','--Config',help="Configuration Properties File Path",required = True)
#('-F','--FileToProcess',help="Input File to Process (In case of Single File)",required = True)
#('-D','--DataSetName',help="DataSetName of File to Process (In case of Single File)",required = True)
#('-B','--BusinessDate',help="BusinessDate",required = True)
#('-L','--LoggingLevel',choices=['DEBUG', 'INFO', 'WARNING','ERROR'],help="BusinessDate",required = True)